class ApplicationConfig:
    DB_PATH = "db/disha.db"